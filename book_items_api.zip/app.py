
import os
from typing import List, Optional, Dict, Any
from uuid import uuid4

from fastapi import FastAPI, HTTPException, Query, status, UploadFile, File, Form, Request
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, HttpUrl, conint, confloat
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient

# -------------------------
# .env configuration
# -------------------------
load_dotenv()

MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DB = os.getenv("MONGODB_DB", "booksdb")
MONGODB_COLLECTION = os.getenv("MONGODB_COLLECTION", "categories")
STATIC_IMG_DIR = os.getenv("STATIC_IMG_DIR", "img")
APP_NAME = os.getenv("APP_NAME", "Book Categories API")

# Ensure images folder exists
os.makedirs(STATIC_IMG_DIR, exist_ok=True)

app = FastAPI(title=APP_NAME, version="3.0.0")

# Serve images as static files: http://localhost:8000/img/<filename>
app.mount("/img", StaticFiles(directory=STATIC_IMG_DIR), name="img")

# Mongo client
client = AsyncIOMotorClient(MONGODB_URI)
db = client[MONGODB_DB]
collection = db[MONGODB_COLLECTION]

# -------------------------
# Models
# -------------------------
class Item(BaseModel):
    id: conint(ge=1) = Field(..., description="Unique numeric identifier")
    name: str = Field(..., min_length=2, max_length=80)
    description: Optional[str] = Field(None, max_length=300)
    grade: confloat(ge=0.0, le=5.0) = Field(0.0, description="Quality/curation score (0–5)")
    image_url: Optional[HttpUrl] = Field(None, description="Public URL served from /img")
    is_active: bool = Field(True)
    version: Optional[str] = Field(None, description="Optional version tag; filter with ?v=")

class PartialItem(BaseModel):
    # All fields optional for PATCH
    name: Optional[str] = Field(None, min_length=2, max_length=80)
    description: Optional[str] = Field(None, max_length=300)
    grade: Optional[float] = Field(None, ge=0.0, le=5.0)
    image_url: Optional[HttpUrl] = None
    is_active: Optional[bool] = None
    version: Optional[str] = None

# -------------------------
# Helpers
# -------------------------
def _mdump(model: BaseModel) -> Dict[str, Any]:
    # pydantic v2 uses model_dump; v1 uses dict()
    return model.model_dump() if hasattr(model, "model_dump") else model.dict()

async def _ensure_indexes():
    # Unique index on id
    await collection.create_index("id", unique=True)
    await collection.create_index("name")
    await collection.create_index("version")

@app.on_event("startup")
async def on_startup():
    await _ensure_indexes()
    # Seed if empty (optional)
    if await collection.count_documents({}) == 0:
        seed = [
            {"id": 1, "name": "Ciencia Ficción", "description": "Utopías y distopías", "grade": 4.7, "image_url": None, "is_active": True, "version": "k"},
            {"id": 2, "name": "No Ficción", "description": "Historia, ensayo", "grade": 4.2, "image_url": None, "is_active": True, "version": "k"},
            {"id": 3, "name": "Fantasía", "description": "Épica y urbana", "grade": 4.5, "image_url": None, "is_active": True, "version": "1"},
            {"id": 4, "name": "Misterio", "description": "Thriller, policial", "grade": 3.9, "image_url": None, "is_active": False, "version": "1"},
            {"id": 5, "name": "Infantil", "description": "Lecturas YA", "grade": 4.1, "image_url": None, "is_active": True, "version": "k"},
        ]
        await collection.insert_many(seed)

# -------------------------
# Endpoints
# -------------------------

# GET all items with optional query params (including ?v=k)
@app.get("/items", response_model=List[Item])
async def list_items(
    min_grade: Optional[float] = Query(None, ge=0.0, le=5.0, description="Minimum grade"),
    name_contains: Optional[str] = Query(None, min_length=1, description="Case-insensitive substring in name"),
    is_active: Optional[bool] = Query(None, description="Filter by active state"),
    v: Optional[str] = Query(None, description="Version tag, e.g., /items?v=k"),
    limit: int = Query(200, ge=1, le=1000),
    skip: int = Query(0, ge=0),
):
    query: Dict[str, Any] = {}
    if min_grade is not None:
        query["grade"] = {"$gte": min_grade}
    if name_contains:
        query["name"] = {"$regex": name_contains, "$options": "i"}
    if is_active is not None:
        query["is_active"] = is_active
    if v is not None:
        query["version"] = v

    cursor = collection.find(query, {"_id": 0}).skip(skip).limit(limit)
    results = await cursor.to_list(length=limit)
    return results

# GET one item by id
@app.get("/items/{item_id}", response_model=Item)
async def get_item(item_id: int):
    doc = await collection.find_one({"id": item_id}, {"_id": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="Item not found")
    return doc

# POST (multipart) to create item with optional image from browser
@app.post("/items", response_model=Item, status_code=status.HTTP_201_CREATED)
async def create_item(
    id: int = Form(...),
    name: str = Form(...),
    description: Optional[str] = Form(None),
    grade: float = Form(0.0),
    is_active: bool = Form(True),
    version: Optional[str] = Form(None),
    image: Optional[UploadFile] = File(None),
):
    # Check ID
    if await collection.find_one({"id": id}):
        raise HTTPException(status_code=409, detail="Item ID already exists")

    image_url: Optional[str] = None
    if image is not None:
        if image.content_type is None or not image.content_type.startswith("image/"):
            raise HTTPException(status_code=400, detail="Only image files are allowed")
        ext = os.path.splitext(image.filename or "")[1] or ".bin"
        filename = f"{uuid4().hex}{ext}"
        filepath = os.path.join(STATIC_IMG_DIR, filename)
        with open(filepath, "wb") as f:
            f.write(await image.read())
        image_url = f"/img/{filename}"

    item = Item(
        id=id,
        name=name,
        description=description,
        grade=grade,
        image_url=image_url,
        is_active=is_active,
        version=version,
    )
    await collection.insert_one(_mdump(item))
    return item

# PUT: full replace (except id in path is the source of truth)
@app.put("/items/{item_id}", response_model=Item)
async def put_item(
    item_id: int,
    payload: Item,
):
    if payload.id != item_id:
        raise HTTPException(status_code=400, detail="Body.id must match path item_id")
    res = await collection.replace_one({"id": item_id}, _mdump(payload), upsert=False)
    if res.matched_count == 0:
        # If not exists, create it (common pattern for PUT)
        await collection.insert_one(_mdump(payload))
    doc = await collection.find_one({"id": item_id}, {"_id": 0})
    return doc

# PATCH: partial update (JSON body) OR image-only via multipart at separate endpoint below
@app.patch("/items/{item_id}", response_model=Item)
async def patch_item(item_id: int, patch: PartialItem):
    existing = await collection.find_one({"id": item_id})
    if not existing:
        raise HTTPException(status_code=404, detail="Item not found")

    # Build update dict
    changes = {k: v for k, v in _mdump(patch).items() if v is not None}
    if not changes:
        doc = await collection.find_one({"id": item_id}, {"_id": 0})
        return doc
    await collection.update_one({"id": item_id}, {"$set": changes})
    doc = await collection.find_one({"id": item_id}, {"_id": 0})
    return doc

# PATCH image via browser form
@app.patch("/items/{item_id}/image", response_model=Item)
async def patch_item_image(item_id: int, image: UploadFile = File(...)):
    if image.content_type is None or not image.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="Only image files are allowed")
    ext = os.path.splitext(image.filename or "")[1] or ".bin"
    filename = f"{uuid4().hex}{ext}"
    filepath = os.path.join(STATIC_IMG_DIR, filename)
    with open(filepath, "wb") as f:
        f.write(await image.read())
    image_url = f"/img/{filename}"

    res = await collection.update_one({"id": item_id}, {"$set": {"image_url": image_url}})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Item not found")
    doc = await collection.find_one({"id": item_id}, {"_id": 0})
    return doc

# DELETE one
@app.delete("/items/{item_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_item(item_id: int):
    res = await collection.delete_one({"id": item_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Item not found")
    return None

# Health check (optional)
@app.get("/health")
async def health():
    return {"status": "ok"}

# Run with:
# uvicorn app:app --reload
